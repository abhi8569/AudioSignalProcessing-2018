% Calling Function Sheet8_3(n) where n is the number of sinc fucntion 
% to reconstruct the signal

Sheet8_3(100)
